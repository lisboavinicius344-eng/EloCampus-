# ELO Campus — projeto padronizado

## Estrutura

- `pages/`: páginas HTML do projeto.
- `assets/css/`: CSS global, de layout e estilos específicos por página.
- `assets/js/`: reservado para os scripts referenciados pelos HTMLs.
- `assets/img/`: reservado para logo e imagens referenciadas pelos HTMLs.

## Padronização realizada

- Unificação da base visual em `assets/css/style.css`.
- Unificação da estrutura interna em `assets/css/layout.css`.
- `emprestimos.css` deixou de repetir reset, variáveis, layout, botões e tabelas globais; agora contém apenas os estilos próprios da página e compatibilidades da marcação antiga.
- Correção do caminho do CSS em `pages/emprestimos.html`.
- Preservação dos nomes dos arquivos e das páginas para evitar quebra dos scripts existentes.
- Os arquivos HTML vazios recebidos foram mantidos: `devolucoes.html`, `relatorio.html`, `solicitantes.html` e `usuarios.html`.

## Observação

Os anexos recebidos continham apenas HTML e CSS. Os scripts JavaScript, a logo e outras imagens referenciadas pelos HTMLs não foram incluídos; por isso foram deixadas as pastas `assets/js/` e `assets/img/` preparadas para receber esses arquivos.

## Origem dos arquivos

- Conjunto do amigo: `pages/emprestimos.html` e `assets/css/emprestimos.css`.
- Seu conjunto: os demais HTMLs e arquivos CSS.

## Integração dos últimos arquivos recebidos

- Adicionadas as páginas `devolucoes.html`, `novo-emprestimo.html`, `relatorio.html`, `solicitantes.html` e `usuarios.html`.
- Adicionados `devolucoes.css`, `novo-emprestimo.css` e `relatorio.css`.
- Essas páginas agora carregam a sequência `style.css` → `layout.css` → `emprestimos.css` → CSS específico da página.
- O `layout.css` vazio recebido não substituiu o layout completo já existente.
- A versão mais completa de `equipamentos.css` foi mantida para preservar os estilos do formulário, listagem e detalhe.
